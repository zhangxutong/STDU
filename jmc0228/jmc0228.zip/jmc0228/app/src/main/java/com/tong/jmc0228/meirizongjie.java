package com.tong.jmc0228;

public class meirizongjie {
    private String riqi_nian;
    private String riqi_yue;
    private String riqi_ri;
    private String guanjianzi;
    private String zongjie;
    private String jianchitianshu;
    private String zuichangtianshu;
    private String zhanghao;

    public String getRiqi_nian() {
        return riqi_nian;
    }

    public void setRiqi_nian(String riqi_nian) {
        this.riqi_nian = riqi_nian;
    }

    public String getRiqi_yue() {
        return riqi_yue;
    }

    public void setRiqi_yue(String riqi_yue) {
        this.riqi_yue = riqi_yue;
    }

    public String getRiqi_ri() {
        return riqi_ri;
    }

    public void setRiqi_ri(String riqi_ri) {
        this.riqi_ri = riqi_ri;
    }

    public String getGuanjianzi() {
        return guanjianzi;
    }

    public void setGuanjianzi(String guanjianzi) {
        this.guanjianzi = guanjianzi;
    }

    public String getZongjie() {
        return zongjie;
    }

    public void setZongjie(String zongjie) {
        this.zongjie = zongjie;
    }

    public String getJianchitianshu() {
        return jianchitianshu;
    }

    public void setJianchitianshu(String jianchitianshu) {
        this.jianchitianshu = jianchitianshu;
    }

    public String getZuichangtianshu() {
        return zuichangtianshu;
    }

    public void setZuichangtianshu(String zuichangtianshu) {
        this.zuichangtianshu = zuichangtianshu;
    }

    public String getZhanghao() {
        return zhanghao;
    }

    public void setZhanghao(String zhanghao) {
        this.zhanghao = zhanghao;
    }

    public meirizongjie(String riqi_nian, String riqi_yue, String riqi_ri, String guanjianzi, String zongjie, String jianchitianshu, String zuichangtianshu, String zhanghao) {
        this.riqi_nian = riqi_nian;
        this.riqi_yue = riqi_yue;
        this.riqi_ri = riqi_ri;
        this.guanjianzi = guanjianzi;
        this.zongjie = zongjie;
        this.jianchitianshu = jianchitianshu;
        this.zuichangtianshu = zuichangtianshu;
        this.zhanghao = zhanghao;
    }
}
